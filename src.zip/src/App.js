// App.js
import React from 'react';
import './App.css';
import Sidebar from './components/Sidebar';
import Content from './components/Content';
import Header from './components/header';

function App() {
  return (
    <div className="App">
      <Header />
      <main className="App-main">
        <Sidebar />
        <Content />
      </main>
      <footer className="App-footer">
        Thanks for watching
      </footer>
    </div>
  );
}

export default App;


