// Sidebar.js
import React from 'react';

function Sidebar() {
  return (
    <div className="sidebar">
      <ul>
        <li><a href="https://youtu.be/yLE5bDX7M3Y?si=k4GybndjCQ-4nemC" target="_blank" rel="noopener noreferrer">Trip 1</a></li>
        <li><a href="https://youtu.be/ZChnh9Z3r48?si=Plb5_c59_xRC6aHb" target="_blank" rel="noopener noreferrer">Trip 2</a></li>
        <li><a href="https://youtu.be/kRZLUCWswlw?si=o-DE26LnT5k91dNz" target="_blank" rel="noopener noreferrer">Trip 3</a></li>
        <li><a href="https://youtu.be/2lUkBy4UgLQ?si=KCmwLqv67dOC1NuZ" target="_blank" rel="noopener noreferrer">Trip 4</a></li>
      </ul>
    </div>
  );
}

export default Sidebar;
